package com.example.tecsup.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class AdaptadorSpinner extends BaseAdapter {

    Context c;
    List<Persona> datos;
    int layout;

    public AdaptadorSpinner(Context c, List<Persona> datos, int layout) {
        this.c = c;
        this.datos = datos;
        this.layout = layout;
    }

    @Override
    public int getCount() {
        return datos.size();
    }

    @Override
    public Object getItem(int position) {
        return datos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater  = LayoutInflater.from(c);
        convertView = inflater.inflate(layout,null);
        TextView tv = convertView.findViewById(R.id.txt_spinner);
        ImageView imageView = convertView.findViewById(R.id.imageView_este);
        tv.setText(datos.get(position).nombre);
        imageView.setImageResource(datos.get(position).icono);
        return convertView;
    }
}

package com.example.tecsup.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Spinner opciones;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        opciones = findViewById(R.id.spinner);
        /*List<String> datos = new ArrayList<>();
        datos.add(getString(R.string.sexo_1));
        datos.add(getString(R.string.sexo_2));
        */
        //String[] datos2 = getResources().getStringArray(R.array.opciones_sexo);
        List<Persona> datos = new ArrayList<>();
        datos.add(new Persona("45463902","marco",R.drawable.ic_keyboard_arrow_right_black_24dp));
        datos.add(new Persona("45464748","pamela",R.drawable.ic_keyboard_hide_black_24dp));

        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,R.layout.item_spinner,datos2);
        AdaptadorSpinner adapter = new AdaptadorSpinner(this,datos,R.layout.item_spinner);
        opciones.setAdapter(adapter);
    }
}

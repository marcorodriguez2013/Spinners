package com.example.tecsup.myapplication;

public class Persona {
    String dni;
    String nombre;
    int icono;

    public Persona(String dni, String nombre, int icono) {
        this.dni = dni;
        this.nombre = nombre;
        this.icono = icono;
    }
}
